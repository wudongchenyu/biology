package pers.wdcy.pool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
