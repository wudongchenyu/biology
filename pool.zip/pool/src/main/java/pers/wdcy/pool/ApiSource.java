package pers.wdcy.pool;

import java.util.Objects;

import org.gitlab4j.api.GitLabApi;

public class ApiSource{
	
	public GitLabApi gitLabApi = new GitLabApi("","");

	void destroy() {
		
	};
	
	boolean validate() {
		return Objects.nonNull(getClass());
	};
	
	
	GitLabApi connect() {
		return gitLabApi;
	};
}
