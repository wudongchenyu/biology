package pers.wdcy.pool;

import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class ApiPool {
	
	private final static int DEFAULE_CORE_POOL_SIZE = 1;
    private final static int DEFAULE_MAX_POOL_SIZE = 5;
    private final static int DEFAULT_OFFER_TIME = 30000;
    private final static int DEFAULT_POLL_TIME = 30000;
    private ApiSourceFactory<ApiSource> ApiSourceFactory;
    private int maxPoolSize;
    private int corePoolSize;
    private int offerTime;
    private int pollTime;
    private AtomicInteger activeNum = new AtomicInteger();
    private BlockingQueue<ApiSource> pool;

    public ApiPool(ApiSourceFactory<ApiSource> ApiSourceFactory) {
        this(DEFAULE_CORE_POOL_SIZE, DEFAULE_MAX_POOL_SIZE, DEFAULT_POLL_TIME, DEFAULT_OFFER_TIME, ApiSourceFactory);
    }

    public ApiPool(int corePoolSize, int maxPoolSize, int pollTime, int offerTime, ApiSourceFactory<ApiSource> ApiSourceFactory) {
        this.corePoolSize = corePoolSize;
        this.maxPoolSize = maxPoolSize;
        this.pollTime = pollTime;
        this.offerTime = offerTime;
        this.ApiSourceFactory = ApiSourceFactory;
        pool = new ArrayBlockingQueue<>(maxPoolSize);
        init();
    }

    public void init() {
        for (int i = 0; i < corePoolSize; i++) {
            try {
                addObject();
            } catch (Exception e) {
                throw new RuntimeException("对象池初始化失败！");
            }
        }
    }

    public ApiSource borrowObject() throws Exception, NoSuchElementException, IllegalStateException {
        if (getNumIdle() == 0 && getNumActive() < maxPoolSize) {
            synchronized (this) {
                if (getNumIdle() == 0 && getNumActive() < maxPoolSize) {
                    return directReturnObject();
                }
            }
        }
        ApiSource ApiSource = pool.poll(pollTime, TimeUnit.SECONDS);
        if (Objects.nonNull(ApiSource)) {
            activeNum.incrementAndGet();
            return ApiSource;
        } else {
            return directReturnObject();
        }
    }

    /**
     * 归还一个对象到池中
     */
    public void returnObject(ApiSource ApiSource) throws Exception {
        try {
            if (Objects.nonNull(ApiSource) && !pool.offer(ApiSource, offerTime, TimeUnit.SECONDS)) {
                destroyObject(ApiSource);
            }
        } finally {
            activeNum.decrementAndGet();
        }
    }

    /**
     * 是指定对象从池中失效
     */
    public void invalidateObject(ApiSource ApiSource) throws Exception {
        pool.remove(ApiSource);
    }

    /**
     * 池中增加一个对象
     */
    public void addObject() throws Exception, IllegalStateException, UnsupportedOperationException {
        pool.offer(createObject(), offerTime, TimeUnit.SECONDS);
    }

    /**
     * 获取池中空闲对象数量
     */
    public int getNumIdle() {
        return pool.size();
    }

    /**
     * 获取使用中的对象数量
     */
    public int getNumActive() {
        return activeNum.get();
    }

    /**
     * 销毁指定对象
     */
    private void destroyObject(ApiSource ApiSource) {
        if (Objects.nonNull(ApiSource)) {
            ApiSource.destroy();
        }
    }

    /**
     * 创建对象并返回
     */
    ApiSource createObject() {
        return ApiSourceFactory.create();
    }

    /**
     * 创建的对象直接返回
     */
    private synchronized ApiSource directReturnObject() {
        activeNum.incrementAndGet();
        return createObject();
    }

    /**
     * 清空对象池
     */
    public void clear() throws Exception, UnsupportedOperationException {
        pool.clear();
    }

    /**
     * 关闭对象池
     */
    public void close() {
        pool.clear();
        pool = null;
    }

}
