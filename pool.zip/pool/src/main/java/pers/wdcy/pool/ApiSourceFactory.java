package pers.wdcy.pool;

@SuppressWarnings("hiding")
public interface ApiSourceFactory<ApiSource> {

	ApiSource create();
	
}
