package pers.wdcy.pool;

import java.util.NoSuchElementException;

import org.gitlab4j.api.GitLabApi;

public class ApiPoolTest {

	public static void main(String[] args) throws NoSuchElementException, IllegalStateException, Exception {
		ApiPool pool = new ApiPool(1, 10, 0, 0, null);
		ApiSource apiSource = pool.borrowObject();
		GitLabApi connect = apiSource.connect();
		GitLabApi connect2 = apiSource.connect();
		System.out.println(connect == connect2);
		
	}

}
